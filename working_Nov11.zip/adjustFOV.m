function FOV_new = adjustFOV(GIFOV)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

FOV_new = 1000*((GIFOV+39.311)/111.9);

end

